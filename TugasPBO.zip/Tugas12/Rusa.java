/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas12;

/**
 *
 * @author Hp
 */
public class Rusa extends Herbivora{
     public Rusa(){
        System.out.println("Ini adalah detail hewan Herbivora : Rusa");
    }
}
