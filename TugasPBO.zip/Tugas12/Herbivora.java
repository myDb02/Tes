/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas12;

/**
 *
 * @author Hp
 */
public class Herbivora {
    private double berat;
    private String makanan,nama,jenis,lokasi;
    
    public double getBerat(){
        return berat;
    }
    
    public void setBerat(double berat){
        this.berat = berat;
    }
    
    public String getMakanan(){
        return makanan;
    }
    
    public void setMakanan(String makanan){
        this.makanan = makanan;
    }
    
    public String getNama(){
        return nama;
    }
    
    public void setNama(String nama){
        this.nama = nama;
    }
    
    public String getJenis(){
        return jenis;
    }
    
    public void setJenis(String jenis){
        this.jenis = jenis;
    }
    
    public String getLokasi(){
        return lokasi;
    }
    
    public void setLokasi(String lokasi){
        this.lokasi = lokasi;
    }
    
    public void tampilkan(){
        System.out.println("Nama            : "+getNama());
        System.out.println("Berat           : "+getBerat());
        System.out.println("Makanan         : "+getMakanan());
        System.out.println("Jenis kelamin   : "+getJenis());
        System.out.println();
    }
}
