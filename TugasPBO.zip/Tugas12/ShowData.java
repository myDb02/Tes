/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Tugas12;

/**
 *
 * @author Hp
 */
public class ShowData {
    public static void main(String args[]){
        Rusa rusa = new Rusa();
        rusa.setNama("Rusa Merah");
        rusa.setBerat(200);
        rusa.setJenis("Jantan");
        rusa.setMakanan("Tumbuh-Tumbuhan");
        rusa.tampilkan();
        
        Sapi sapi = new Sapi();
        sapi.setNama("Sapi Hereford");
        sapi.setBerat(756);
        sapi.setJenis("Betina");
        sapi.setMakanan("Tumbuh-Tumbuhan");
        sapi.tampilkan();
        
        Zebra zebra = new Zebra();
        zebra.setNama("Zebra Gunung");
        zebra.setBerat(280);
        zebra.setJenis("Betina");
        zebra.setMakanan("Tumbuh-Tumbuhan");
        zebra.tampilkan();
    }
}
